import java.util.Scanner;
//Sistema de calculos y de uso de datos proporcionados por el usuario para cumplir la función del programa
public class Esfera {

    private double radio;

    public Esfera(double radio) {
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public double calcularArea() {
        return 4 * Math.PI * Math.pow(radio, 2);
    }

    public double calcularVolumen() {
        return (4 * Math.PI * Math.pow(radio, 3)) / 3;
    }

    public void mostrarResultados() {
        System.out.println("\n--- Resultados de la Esfera ---");
        System.out.printf("Radio     : %.2f%n", radio);
        System.out.printf("Área      : %.2f%n", calcularArea());
        System.out.printf("Volumen   : %.2f%n", calcularVolumen());
        System.out.println("-------------------------------");
    }
}