import java.util.Scanner;

public class Main {
//Calculos del main sobre el radio y la petición de datos al usuario
    public static void main(String[] args) {

        double radio = pedirRadio();
        Esfera esfera = new Esfera(radio);
        esfera.mostrarResultados();
    }

    public static double pedirRadio() {

        Scanner teclado = new Scanner(System.in);
        double radio;

        do {
            System.out.println("Introduce el radio de la esfera (valor mayor que 0):");
            radio = teclado.nextDouble();
        } while (radio <= 0);

        teclado.close();
        return radio;
    }
}